# Convert Files To PDF

Commands below are written relative to the PDF skill directory. If your shell is elsewhere, `cd` to the skill directory first or prefix `scripts/...` with that directory.

## DOCX/PPTX/ODT -> PDF (LibreOffice)

```bash
python scripts/lo_convert_to_pdf.py input.docx --out_dir /mnt/data/out
```

Success criteria:

- A PDF appears in the output directory
- Render it with `render_pdf.py` before considering it done
- Inspect page images for obvious pagination/font/layout surprises

## HTML -> PDF

This path is unavailable in the gaas-base cloud image because Chromium/Playwright are not installed. The local `html_to_pdf.py` helper exits with a diagnostic instead of silently choosing a worse renderer. Prefer Markdown -> PDF, LaTeX -> PDF, or LibreOffice conversion instead.

## Markdown -> PDF (Pandoc)

```bash
python scripts/md_to_pdf.py input.md -o /mnt/data/out.pdf --pdf_engine xelatex
```

## LaTeX -> PDF

```bash
python scripts/latex_to_pdf.py input.tex -o /mnt/data/out.pdf
```

If you are generating a complex report, LaTeX is often the most predictable way to get a professional PDF.
