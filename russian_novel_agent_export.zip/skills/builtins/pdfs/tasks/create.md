# Create A PDF In gaas-base

Pick the simplest available authoring pipeline, then render and inspect the PDF before calling it done.

Commands below are written relative to the PDF skill directory. If your shell is elsewhere, `cd` to the skill directory first or prefix `scripts/...` with that directory.

## Preferred Pipelines

### DOCX or PPTX -> PDF

Use this when the PDF is a business document, Word-like memo/report, or slide-like deck. Author with the DOCX or Slides skill, then convert with LibreOffice:

```bash
python scripts/lo_convert_to_pdf.py input.docx --out_dir /mnt/data/out
```

### Markdown -> PDF

Use this for straightforward text-heavy documents:

```bash
python scripts/md_to_pdf.py input.md -o /mnt/data/out.pdf --pdf_engine xelatex
```

### LaTeX -> PDF

Use this for typeset reports, equations, references, and long-form docs:

```bash
python scripts/latex_to_pdf.py input.tex -o /mnt/data/out.pdf
```

### ReportLab

Use this for fully programmatic PDFs such as certificates, labels, invoices, or generated reports. Create the PDF from a Python script, then render it for visual QA.

## Unavailable Here

Do not choose an HTML+CSS -> PDF workflow in the gaas-base cloud image: Chromium and Playwright are not installed here, and `html_to_pdf.py` is intentionally disabled.

## Quality Loop

1. Generate the PDF.
2. Render it:

```bash
python scripts/render_pdf.py /mnt/data/out.pdf --out_dir /mnt/data/_renders/out --dpi 200
```

3. Inspect page images for clipping, overlap, broken glyphs, missing charts, awkward page breaks, and font/layout surprises.
4. Iterate on the source document.
5. Keep only the final deliverable in the user-facing output directory.
