#!/usr/bin/env python3
"""Document the gaas-base PDF skill's no-browser HTML conversion behavior."""

from __future__ import annotations


def main() -> int:
    raise SystemExit(
        "HTML -> PDF conversion via Playwright/Chromium is unavailable in the gaas-base "
        "cloud image. Use md_to_pdf.py, latex_to_pdf.py, or lo_convert_to_pdf.py instead."
    )


if __name__ == "__main__":
    raise SystemExit(main())
