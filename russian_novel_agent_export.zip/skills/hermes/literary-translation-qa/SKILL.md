---
name: literary-translation-qa
description: Use when reviewing or polishing translated literary prose for accuracy, fluency, tone, rhythm, consistency, and natural Chinese expression without drifting from the source.
---

# Literary Translation QA

## Overview

Use this skill when the task is to inspect, improve, or validate literary translation quality after a draft exists.

This skill is for the second pass: not deciding where to continue, but improving how the translated text reads while keeping it faithful to the source.

## When To Use

Use `$literary-translation-qa` for requests like:

- Review this translated chapter and improve readability.
- Check whether the Chinese translation preserves the tone and emotional force of the Russian original.
- Polish the draft without changing plot facts, speaker intent, or established terminology.

Do not use this skill as the primary workflow for continuation tracking. If the main task is resuming a long translation, use `$novel-translation-continuity` first.

## QA Priorities

Review in this order:

1. Accuracy
2. Continuity with established terminology and names
3. Tone and narrative voice
4. Natural Chinese expression
5. Rhythm, readability, and literary finish

Do not sacrifice a higher priority to improve a lower one.

## Workflow

1. Compare the translated passage against the source passage.
   - Check factual meaning, speaker identity, action sequence, and emotional direction.
   - Flag mistranslations, omissions, additions, and register shifts.

2. Check continuity constraints.
   - Preserve established names, titles, nicknames, military terms, and recurring motifs.
   - Do not introduce alternate renderings just for variety.

3. Polish sentence-level expression.
   - Replace stiff or mechanical phrasing with natural Chinese prose.
   - Keep profanity, roughness, lyricism, or brutality when the source calls for it.
   - Preserve pacing: clipped where tense, expansive where reflective.

4. Check dialogue quality.
   - Make each speaker sound human and context-appropriate.
   - Preserve differences in education level, hierarchy, sarcasm, fatigue, panic, and intimacy.
   - Avoid making all speakers sound equally polished.

5. Deliver the revised translation.
   - If only minor issues exist, silently tighten them in the polished output.
   - If major fidelity problems exist, correct them before doing stylistic refinement.

## Editing Rules

- Do not embellish plot facts.
- Do not flatten the emotional intensity of war scenes, fear, grief, or brutality.
- Do not over-literaryize plain, harsh, or vulgar source passages.
- Do not domesticate culturally specific details unless comprehension truly requires it.
- If a line is ambiguous in the source, prefer a restrained Chinese rendering over an overconfident interpretation.

## Output Contract

The final output should read like publishable Chinese literary prose while remaining faithful to the source.

A successful pass should improve:

- clarity
- fluency
- tonal precision
- character voice
- sentence rhythm

without changing:

- plot facts
- who did what
- temporal sequence
- established terminology
- narrator perspective

## Example

User request:
- Polish this translated section so it reads naturally in Chinese but stays faithful to the original Russian.

Successful behavior:
- Correct factual or tonal drift first.
- Preserve prior naming and terminology.
- Tighten stiff phrasing into natural literary Chinese.
- Keep the original harshness, tenderness, or brutality where the source carries it.
