---
name: novel-translation-continuity
description: Use when continuing a long-form fiction translation from earlier chapters, maintaining names, terminology, voice, timeline, and progress across multiple runs.
---

# Novel Translation Continuity

## Overview

Use this skill whenever the task is to continue, resume, or stabilize a long fiction translation across multiple runs.

This skill exists to prevent drift in:

- names, titles, and forms of address
- military or domain terminology
- narrator voice and register
- chapter boundaries and continuation points
- previously established translation decisions

## When To Use

Use `$novel-translation-continuity` for requests like:

- Continue translating the next chapter of this novel from the attached PDF.
- Resume from the last completed section and keep all names and style consistent.
- Check where the previous run stopped and continue without repeating or skipping content.

Do not use this skill for final polish-only work when continuity is already settled and the main task is stylistic cleanup. In that case, use `$literary-translation-qa`.

## Workflow

1. Identify the current source span to translate.
   - Prefer explicit chapter or section boundaries.
   - If boundaries are unclear, choose the smallest natural continuation point that preserves scene integrity.

2. Recover the established translation state before translating.
   - Read any available continuity state from Memory, especially glossaries, style notes, and progress logs.
   - Reuse prior decisions unless the source clearly proves they were wrong.
   - If continuity files are missing, initialize them from the current source and current translation context instead of blocking.

3. Determine the continuation point.
   - First look for the last completed chapter, section, or paragraph range in the progress record.
   - If the previous stopping point is uncertain, choose the earliest clearly unfinished natural segment.
   - Avoid redoing already completed text unless the task explicitly asks for revision.

4. Translate for continuity first, elegance second.
   - Preserve established naming, rank, address, and terminology choices.
   - Keep the same narration distance, emotional intensity, and sentence rhythm unless the source itself shifts.
   - Treat repeated motifs, repeated phrases, and callbacks as continuity signals, not fresh wording opportunities.

5. Update continuity state after each meaningful chunk.
   - Record new names, terms, or translation decisions.
   - Record the completed range precisely enough for the next run to continue.
   - Note unresolved ambiguities that should be handled consistently later.

## Continuity Rules

- Prefer stable translations over clever rephrasing.
- Keep one canonical Chinese rendering for each recurring proper noun unless there is a strong source-based reason to change it.
- Preserve distinctions between narration, dialogue, internal thought, military jargon, slang, and profanity.
- If a literal choice would break continuity with prior accepted translation, prefer the established choice and note the exception only if it matters.
- If OCR noise or broken source text creates uncertainty, make the narrowest safe interpretation and record the uncertainty in the continuity notes.

## Output Contract

When this skill is active, the resulting translation work should produce:

1. the next continuous translated passage
2. stable terminology and naming choices
3. an updated progress marker for future continuation
4. any newly needed glossary or style updates

If a blocker prevents reliable continuation, state exactly what span is blocked and continue with any earlier or adjacent safe span when possible.

## Example

User request:
- Continue the next part of the novel from the attached PDF and keep previous naming consistent.

Successful behavior:
- Find the last completed point.
- Continue from the next natural section.
- Reuse all established name and term choices.
- Avoid repeating already translated material.
- Update the progress record after finishing the new section.
