# 俄语小说译中助手导出包

导出时间：2026-06-24 14:43 AEST 左右  
工作区：`/workspace`  
智能体角色：俄语小说译中助手

## 包含内容

- `agent_config/AGENTS.md`  
  当前智能体的主要说明文件，包含角色、源文件处理方式、翻译流程、输出要求、Memory 维护规则和安全约束。

- `agent_files/`  
  当前智能体文件区中可见的附件与阶段性文档，包括俄语小说 PDF 源文件和已生成的阶段译稿 DOCX。

- `skills/`  
  当前运行环境中可见的 Codex/Hermes skills，包括小说续译、文学翻译校对、PDF、DOCX、幻灯片、表格、图像生成、前端等技能说明。

- `memory/`  
  当前持久化 memory 文件，不含内部版本控制目录。现有文件包括：
  - `translation-glossary.md`
  - `style-notes.md`
  - `progress-log.md`

- `schedules/schedules.json`  
  当前智能体已配置的定时任务记录，包括启用状态、频率、时区和运行提示词。

- `MANIFEST.txt`  
  压缩包内文件清单。

## 当前定时任务摘要

当前存在 1 个启用的定时任务：

- 频率：每 1 小时运行一次
- 时区：Australia/Sydney
- 用途：继续处理已附加俄语小说 PDF《Промка (Дмитрий Филиппов) (z-library.sk, 1lib.sk, z-lib.sk).pdf》的中文翻译任务，并在每轮运行中读取和更新 Memory。

详细提示词见 `schedules/schedules.json`。

## 备注

此压缩包用于备份和迁移当前智能体可见信息。若在其他环境恢复使用，建议先检查：

1. `agent_config/AGENTS.md` 是否被目标环境识别为智能体说明。
2. `agent_files/` 中的 PDF 和阶段译稿是否放在目标环境约定的附件位置。
3. `memory/` 是否恢复到目标环境的持久化 memory 目录。
4. `skills/` 中的技能是否需要按目标环境的技能安装机制重新安装。
5. 定时任务通常需要在目标环境重新创建，提示词可直接参考 `schedules/schedules.json`。
